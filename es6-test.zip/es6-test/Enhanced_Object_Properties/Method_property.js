// Enhanced Object Properties
// Method Properties
// Support for method notation in object property definitions, for both regular functions and generator functions.

var obj = {
    frist(a,b){
        a+b;
    },
    sec(a,b){
        a*b;
    },
    third(a,b){
        a-b;
    }
}

console.log(obj);