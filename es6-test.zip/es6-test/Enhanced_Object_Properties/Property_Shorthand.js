let x = 10,
    y = 20;

let obj = {
    x,
    y
}
console.log(obj);