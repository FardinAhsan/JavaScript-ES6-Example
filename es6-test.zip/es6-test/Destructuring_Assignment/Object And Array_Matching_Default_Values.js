// Destructuring Assignment
// Object And Array Matching, Default Values
// Simple and intuitive default values for destructuring of Objects and Arrays.

