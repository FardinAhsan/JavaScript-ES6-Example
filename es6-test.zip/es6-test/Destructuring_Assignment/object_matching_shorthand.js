// Object Matching, Shorthand Notation
// Intuitive and flexible destructuring of Objects into individual variables during assignment.

function getASTNode() {
  return {op: 1, lhs: 2, rhs: 3};
};

var {op, lhs, rhs} = getASTNode();

console.log(`Value op:`, op);
console.log(`Value lhs:`, lhs);
console.log(`Value rhs:`, rhs);