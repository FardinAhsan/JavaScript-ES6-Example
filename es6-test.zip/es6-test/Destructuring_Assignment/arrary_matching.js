// Destructuring Assignment
// Array Matching
// Intuitive and flexible destructuring of Arrays into individual variables during assignment.

var num = [1,2,3];

var [a,,b] = num;

console.log(a);
console.log(b);

[a,b] = [b,a];

console.log(a);
console.log(b);