var nums = [2,5,10];
var fives=[];

// nums.forEach(element => {
    
// });
nums.forEach(v => {
    if (v % 5 === 0)
        fives.push(v)
 })

 console.log(fives);