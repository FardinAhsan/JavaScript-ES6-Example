let a=[1,2,3,4,44,50,20],
    b=['fs','sdf','dfd','dfdk'];
for (let i = 0; i < a.length; i++) {
    let x = a[i];
    // console.log(x);
}
for (let i = 0; i < b.length; i++) {
    let y = b[i];
}

let callbacks = []
for (let i = 0; i <= 2; i++) {
    callbacks[i] = function () { console.log( i * 2) }
}
callbacks[0]();
callbacks[1]();
callbacks[2]();